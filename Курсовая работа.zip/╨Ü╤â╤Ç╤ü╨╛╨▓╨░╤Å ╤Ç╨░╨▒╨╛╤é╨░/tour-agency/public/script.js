// document.addEventListener("DOMContentLoaded", () => {
//   // Модальное окно
//   const modal = document.querySelector(".modal");
//   const modalCloseBtn = document.querySelector(".close-btn");

//   // Кнопки "Подробнее"
//   const moreInfoButtons = document.querySelectorAll(".more-info-btn");

//   // Кнопки "Забронировать"
//   const bookButtons = document.querySelectorAll(".tour-buttons button:nth-child(2)");

//   // Открытие модального окна
//   moreInfoButtons.forEach(button => {
//     button.addEventListener("click", () => {
//       modal.classList.remove("hidden");
//     });
//   });

//   // Закрытие модального окна по кнопке
//   modalCloseBtn.addEventListener("click", () => {
//     modal.classList.add("hidden");
//   });

//   // Закрытие модального окна по клику вне области
//   window.addEventListener("click", (event) => {
//     if (event.target === modal) {
//       modal.classList.add("hidden");
//     }
//   });

//   // Обработка бронирования тура
//   bookButtons.forEach(button => {
//     button.addEventListener("click", () => {
//       const tourCard = button.closest(".tour-card");
//       const tourTitle = tourCard.querySelector("h3").innerText;
//       alert(`Вы успешно забронировали тур: ${tourTitle}`);
//     });
//   });
// });
const tours = [
  {
    id: 1,
    title: "Пляжный отдых в Турции",
    description: "7 дней / Всё включено",
    details: "Этот тур включает перелёт, проживание в 4* отеле, питание по системе «всё включено» и экскурсионную программу.",
    image: "https://safety-rest.ru/upload/iblock/fbc/chto-mozhno-uznat-o-turtsii.jpg",
    destination: "Турция",
    duration: 7,
    startDate: "2025-07-01"
  },
  {
    id: 2,
    title: "Горнолыжный тур в Швейцарии",
    description: "14 дней / Завтраки включены",
    details: "Прекрасные горы, снежные склоны и уютные шале. Трансфер и снаряжение включены.",
    image: "https://media.myswitzerland.com/image/fetch/c_lfill,g_auto,w_3200,h_1800/f_auto,q_80,fl_keep_iptc/https://www.myswitzerland.com/-/media/celum%20connect/2022/04/12/13/25/06/corvatsch-skiers-and-snowboarders.jpg",
    destination: "Швейцария",
    duration: 14,
    startDate: "2025-12-15"
  }
];

const tourResults = document.getElementById("tourResults");
const searchForm = document.getElementById("searchForm");
const modal = document.querySelector(".modal");
const modalContentParagraph = modal.querySelector(".modal-content p");
const closeBtn = modal.querySelector(".close-btn");

// Рендер туров
function renderTours(filteredTours) {
  tourResults.innerHTML = "";

  if (filteredTours.length === 0) {
    tourResults.innerHTML = "<p>Туры не найдены. Попробуйте изменить параметры поиска.</p>";
    return;
  }

  filteredTours.forEach(tour => {
    const card = document.createElement("div");
    card.className = "tour-card";
    card.innerHTML = `
      <img src="${tour.image}" alt="${tour.title}" />
      <div class="tour-content">
        <h3>${tour.title}</h3>
        <p>${tour.description}</p>
        <div class="tour-buttons">
          <button class="more-info-btn" data-id="${tour.id}">Подробнее о туре</button>
          <button class="book-btn" data-id="${tour.id}">Забронировать</button>
        </div>
      </div>
    `;
    tourResults.appendChild(card);
  });

  // Кнопка "Подробнее"
  document.querySelectorAll(".more-info-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const id = +e.target.dataset.id;
      const tour = tours.find(t => t.id === id);
      if (tour) {
        showModal(tour.details);
      }
    });
  });

  // Кнопка "Забронировать"
  document.querySelectorAll(".book-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const id = +e.target.dataset.id;
      const tour = tours.find(t => t.id === id);
      if (tour) {
        alert(`Вы забронировали тур: "${tour.title}"! Спасибо за заказ.`);
      }
    });
  });
}

// Функция отображения модального окна
function showModal(text) {
  modalContentParagraph.textContent = text;
  modal.classList.remove("hidden");
}

// Закрытие модального окна
closeBtn.addEventListener("click", () => {
  modal.classList.add("hidden");
});

// Закрытие при клике вне модального контента
modal.addEventListener("click", (e) => {
  if (e.target === modal) {
    modal.classList.add("hidden");
  }
});

// Обработка формы поиска
searchForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const destinationValue = document.getElementById("destination").value.trim().toLowerCase();
  const durationValue = document.getElementById("duration").value;
  const startDateValue = document.getElementById("startDate").value;

  let filtered = tours.filter(tour => {
    const matchDestination = destinationValue === "" || tour.destination.toLowerCase().includes(destinationValue);
    const matchDuration = durationValue === "" || tour.duration === +durationValue;
    const matchStartDate = startDateValue === "" || tour.startDate >= startDateValue;
    return matchDestination && matchDuration && matchStartDate;
  });

  renderTours(filtered);
});

// Изначально показываем все туры
renderTours(tours);
