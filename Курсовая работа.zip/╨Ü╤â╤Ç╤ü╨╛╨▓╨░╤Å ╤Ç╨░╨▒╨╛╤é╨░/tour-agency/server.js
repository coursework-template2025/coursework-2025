const express = require('express');
const path = require('path');
const Database = require('better-sqlite3');

const app = express();
const PORT = 3000;
const db = new Database('./db/tours.db');

app.use(express.static('public'));
app.use(express.json());

app.post('/api/search', (req, res) => {
    const { destination, duration, startDate } = req.body;

    let query = `SELECT * FROM tours WHERE 1=1`;
    const params = [];

    if (destination) {
        query += ` AND destination LIKE ?`;
        params.push(`%${destination}%`);
    }

    if (duration) {
        query += ` AND duration = ?`;
        params.push(duration);
    }

    if (startDate) {
        query += ` AND start_date = ?`;
        params.push(startDate);
    }

    const tours = db.prepare(query).all(...params);
    res.json(tours);
});

app.listen(PORT, () => {
    console.log(`Сервер запущен: http://localhost:${PORT}`);
});
