const Database = require('better-sqlite3');
const db = new Database('./db/tours.db');

db.exec(`
CREATE TABLE IF NOT EXISTS tours (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    destination TEXT NOT NULL,
    duration INTEGER,
    start_date TEXT,
    image TEXT
);

INSERT INTO tours (title, destination, duration, start_date, image) VALUES
('Пляжный отдых в Турции', 'Анталия', 7, '2025-07-01', 'https://source.unsplash.com/featured/?beach'),
('Экскурсия по Парижу', 'Париж', 5, '2025-08-10', 'https://source.unsplash.com/featured/?paris'),
('Горы Грузии', 'Тбилиси', 10, '2025-09-05', 'https://source.unsplash.com/featured/?mountains');
`);

console.log('База данных инициализирована.');
