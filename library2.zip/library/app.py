from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.utils import secure_filename
from forms import BookForm
import os
import os



app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///database.db'
app.config['UPLOAD_FOLDER'] = 'static/uploads'

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Инициализация администраторского флага (для простоты, это будет просто переменная)
is_admin = True  # В реальном проекте это будет проверяться через систему аутентификации

from models import Book

@app.route('/')
def index():
    books = Book.query.all()  # Запрос всех книг из базы данных
    return render_template('index.html', books=books)

# add book
@app.route('/add', methods=['GET', 'POST'])
def add_book():
    if not is_admin:  # Проверка прав доступа
        flash('У вас нет прав доступа!', 'danger')
        return redirect(url_for('index'))
    
    form = BookForm()  # Создание формы
    if form.validate_on_submit():
        # Получаем данные из формы
        title = form.title.data
        description = form.description.data
        price = form.price.data
        rating = form.rating.data
        genre = form.genre.data
        
        # Обработка изображения
        image_file = request.files.get('image')  # Получаем файл изображения
        
        image_filename = None  # Стартовое значение для имени файла
        if image_file and image_file.filename != '':
            filename = secure_filename(image_file.filename)  # Безопасное имя файла
            upload_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)  # Путь для сохранения
            image_file.save(upload_path)  # Сохраняем файл
            image_filename = filename  # Записываем имя файла
        
        # Создаём новый объект книги с сохранением имени изображения в БД
        book = Book(
            title=title,
            description=description,
            price=price,
            rating=rating,
            genre=genre,
            image=image_filename  # Сохраняем только имя файла
        )
        
        # Добавляем книгу в базу данных
        db.session.add(book)
        db.session.commit()
        
        flash('Книга успешно добавлена!', 'success')  # Отображаем сообщение об успехе
        return redirect(url_for('index'))  # Перенаправляем на главную страницу

    # Если форма не отправлена или данные некорректные, отобразим форму
    return render_template('add_book.html', form=form)

# edit book
@app.route('/edit/<int:book_id>', methods=['GET', 'POST'])
def edit_book(book_id):
    # Получаем книгу по ID
    book = Book.query.get_or_404(book_id)
    form = BookForm(obj=book)

    if form.validate_on_submit():
        book.title = form.title.data
        book.description = form.description.data
        book.price = form.price.data
        book.rating = form.rating.data
        book.genre = form.genre.data

        # Обработка изображения
        if form.image.data:
            filename = secure_filename(form.image.data.filename)
            form.image.data.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            book.image = filename

        db.session.commit()  # Сохраняем изменения в базе данных
        flash('Книга успешно обновлена!', 'success')
        return redirect(url_for('admin'))  # Перенаправляем в панель администратора

    return render_template('edit_book.html', form=form, book=book)  # Отображаем форму редактирования




#delete book
@app.route('/delete/<int:book_id>', methods=['POST'])
def delete_book(book_id):
    if not is_admin:
        flash('У вас нет прав доступа!', 'danger')
        return redirect(url_for('index'))
    
    book = Book.query.get_or_404(book_id)
    db.session.delete(book)
    db.session.commit()
    flash('Книга удалена!', 'success')
    return redirect(url_for('index'))

# view book
@app.route('/book/<int:book_id>')
def view_book(book_id):
    book = Book.query.get_or_404(book_id)
    return render_template('view_book.html', book=book)

# admin panel
@app.route('/admin')
def admin():
    if not is_admin:
        flash('У вас нет прав доступа!', 'danger')
        return redirect(url_for('index'))
    
    books = Book.query.all()
    return render_template('admin.html', books=books)

if __name__ == '__main__':
    app.run(debug=True)
