from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, FloatField, SelectField
from wtforms.validators import DataRequired

class BookForm(FlaskForm):
    title = StringField('Название', validators=[DataRequired()])
    description = TextAreaField('Описание', validators=[DataRequired()])
    price = FloatField('Цена', validators=[DataRequired()])
    rating = FloatField('Рейтинг', validators=[DataRequired()])
    genre = StringField('Жанр', validators=[DataRequired()])
    image = StringField('Картинка')  # Строка для имени файла картинки
