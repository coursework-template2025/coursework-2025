from app import db

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)          # Название книги
    description = db.Column(db.Text, nullable=False)            # Описание
    price = db.Column(db.Float, nullable=False)                 # Цена
    rating = db.Column(db.Float, nullable=False)                # Рейтинг (например, 4.5)
    genre = db.Column(db.String(100), nullable=False)           # Жанр
    image = db.Column(db.String(100), nullable=True)            # Имя файла изображения

    def __repr__(self):
        return f'<Book {self.title}>'
