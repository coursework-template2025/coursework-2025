import React from 'react';

const ContactPage = () => {
  return (
    <div>
      <h1>Контакты</h1>
      <p>Телефон: +1 800 123 456</p>
    </div>
  );
};

export default ContactPage;
